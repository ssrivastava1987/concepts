package com.apple.dataprovider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataProviderApplicationTests {

	@Test
	void contextLoads() {
	}

}
