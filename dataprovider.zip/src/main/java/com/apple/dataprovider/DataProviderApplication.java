package com.apple.dataprovider;

import java.util.concurrent.TimeUnit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DataProviderApplication {

//	public static void main(String[] args) {
//		SpringApplication.run(DataProviderApplication.class, args);
//	}
	
	public static void main(String[] args) throws Exception {

        ConfigurableApplicationContext context = SpringApplication.run(DataProviderApplication.class, args);
        
        MessageProducer producer = context.getBean(MessageProducer.class);
        MessageListener listener = context.getBean(MessageListener.class);
        for(int i=10;i<20;i++) {
        producer.sendMessage("Hello, World!"+" "+i);
        }
        listener.latch.await(10, TimeUnit.SECONDS);

        context.close();
    }

    @Bean
    public MessageProducer messageProducer() {
        return new MessageProducer();
    }

    @Bean
    public MessageListener messageListener() {
        return new MessageListener();
    }

}
