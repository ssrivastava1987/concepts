//package com.apple.databatch;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class DataBatchApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
