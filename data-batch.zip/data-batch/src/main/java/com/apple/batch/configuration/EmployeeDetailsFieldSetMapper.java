package com.apple.batch.configuration;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.stereotype.Component;

import com.apple.batch.dao.entity.EmployeeDetails;

@Component
public class EmployeeDetailsFieldSetMapper implements FieldSetMapper<EmployeeDetails> {

    @Override
    public EmployeeDetails mapFieldSet(FieldSet fieldSet) {
        final EmployeeDetails employeeDetails = new EmployeeDetails();

//        employeeDetails.setId(fieldSet.readLong("ID"));
        employeeDetails.setPersonalId(fieldSet.readString("personal_id"));
        employeeDetails.setFirstName(fieldSet.readString("first_name"));
        employeeDetails.setLastName(fieldSet.readString("last_name"));
        employeeDetails.setAddressLine1(fieldSet.readString("addr_line_1"));
        employeeDetails.setAddressLine2(fieldSet.readString("addr_line_2"));
        employeeDetails.setCity(fieldSet.readString("city"));
        employeeDetails.setState(fieldSet.readString("state"));
        employeeDetails.setZip(fieldSet.readString("zip"));
        employeeDetails.setDateOfBirth(fieldSet.readString("date_of_birth"));
        employeeDetails.setJobTitle(fieldSet.readString("job_title"));
        employeeDetails.setDeptNumber(fieldSet.readString("dept_number"));
        employeeDetails.setDeptName(fieldSet.readString("dept_name"));
        employeeDetails.setDeptSiteNumber(fieldSet.readString("dept_site_number"));
        employeeDetails.setCompanyName(fieldSet.readString("company_name"));
        employeeDetails.setBuildingName(fieldSet.readString("building_name"));
        employeeDetails.setLocationName(fieldSet.readString("location_name"));
        employeeDetails.setPhone(fieldSet.readString("phone"));
        employeeDetails.setExt(fieldSet.readString("ext"));
        employeeDetails.setMobilePhone(fieldSet.readString("mobile_phone"));
        employeeDetails.setEmailAddress(fieldSet.readString("email_address"));
        employeeDetails.setManagerName(fieldSet.readString("manager_name"));
        employeeDetails.setManagerEmailAddress(fieldSet.readString("manager_email_address"));
        employeeDetails.setManagerPhoneNumber(fieldSet.readString("manager_phone_number"));
        employeeDetails.setAreaManagername(fieldSet.readString("area_manager_name"));
        
        return employeeDetails;

    }
}
