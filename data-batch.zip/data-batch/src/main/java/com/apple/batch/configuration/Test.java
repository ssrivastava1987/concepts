package com.apple.batch.configuration;

import java.io.IOException;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Test {

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		// TODO Auto-generated method stub
		
		String a = "{\n" + 
				"    \"Account\": \"2\",\n" + 
				"    \"ALL REQUEST TYPES\": \"0\",\n" + 
				"    \"Apple Digital Content\": \"2\",\n" + 
				"    \"Financial Transaction\": \"3\",\n" + 
				"    \"Device\": \"1\",\n" + 
				"    \"Other\": \"0\"\n" + 
				"}";
		
		ObjectMapper om = new ObjectMapper();
        Map<String, String> map = om.readValue(a, Map.class);
        JSONArray ja = new JSONArray();
        JSONArray ja1 = new JSONArray();
        for(Map.Entry<String, String> m : map.entrySet()){
        	ja1.put(Integer.parseInt(m.getValue()));
        	ja1.put(m.getKey());
        }
        ja.put(ja1);
        System.out.println(ja.toString());
//        System.out.println(String.format("\t", ja.toString()));
	}

}
