package com.apple.batch.configuration;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import com.apple.batch.dao.entity.EmployeeDetails;

import javax.sql.DataSource;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Bean
    public FlatFileItemReader<EmployeeDetails> reader() {
        return new FlatFileItemReaderBuilder<EmployeeDetails>()
                .name("employeeDetailsItemReader")
                .resource(new ClassPathResource("employeeDetails.csv"))
                .delimited()
                .names(new String[]{"personal_id", "first_name",
                		"last_name","addr_line_1",
                		"addr_line_2","city",
                		"state","zip",
                		"date_of_birth","job_title",
                		"dept_number","dept_name",
                		"dept_site_number","company_name",
                		"building_name","location_name",
                		"phone","ext",
                		"mobile_phone","email_address",
                		"manager_name","manager_email_address",
                		"manager_phone_number","area_manager_name"})
                .lineMapper(lineMapper())
                .fieldSetMapper(new BeanWrapperFieldSetMapper<EmployeeDetails>() {{
                    setTargetType(EmployeeDetails.class);
                }})
                .build();
    }

    @Bean
    public LineMapper<EmployeeDetails> lineMapper() {

        final DefaultLineMapper<EmployeeDetails> defaultLineMapper = new DefaultLineMapper<>();
        final DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
        lineTokenizer.setDelimiter(";");
        lineTokenizer.setStrict(false);
        lineTokenizer.setNames(new String[] {"personal_id", "first_name",
        		"last_name","addr_line_1",
        		"addr_line_2","city",
        		"state","zip",
        		"date_of_birth","job_title",
        		"dept_number","dept_name",
        		"dept_site_number","company_name",
        		"building_name","location_name",
        		"phone","ext",
        		"mobile_phone","email_address",
        		"manager_name","manager_email_address",
        		"manager_phone_number","area_manager_name"});

        final EmployeeDetailsFieldSetMapper fieldSetMapper = new EmployeeDetailsFieldSetMapper();
        defaultLineMapper.setLineTokenizer(lineTokenizer);
        defaultLineMapper.setFieldSetMapper(fieldSetMapper);

        return defaultLineMapper;
    }

    @Bean
    public EmployeeDetailsProcessor processor() {
        return new EmployeeDetailsProcessor();
    }

    @Bean
    public JdbcBatchItemWriter<EmployeeDetails> writer(final DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<EmployeeDetails>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO employeedetails "
                		+ "(personal_id, first_name,last_name,addr_line_1,addr_line_2,city,state,zip,date_of_birth,job_title,dept_number,"
                		+ "dept_name,dept_site_number,company_name,building_name,location_name,phone,ext,mobile_phone,"
                		+ "email_address,manager_name,manager_email_address,manager_phone_number,area_manager_name) "
                		+ "VALUES (:personal_id, :first_name,:last_name,:addr_line_1,:addr_line_2,:city,:state,:zip,:date_of_birth,"
                		+ ":job_title,:dept_number,:dept_name,:dept_site_number,:company_name,:building_name,"
                		+ ":location_name,:phone,:ext,:mobile_phone,:email_address,:manager_name,:manager_email_address,"
                		+ ":manager_phone_number,:area_manager_name)")
                .dataSource(dataSource)
                .build();
    }

    @Bean
    public Job importEmployeeDetailsJob(NotificationListener listener, Step step1) {
        return jobBuilderFactory.get("importEmployeeDetailsJob")
                .incrementer(new RunIdIncrementer())
                .listener(listener)
                .flow(step1)
                .end()
                .build();
    }

    @Bean
    public Step step1(JdbcBatchItemWriter<EmployeeDetails> writer) {
        return stepBuilderFactory.get("step1")
                .<EmployeeDetails, EmployeeDetails> chunk(10)
                .reader(reader())
                .processor(processor())
                .writer(writer)
                .build();
    }
}
