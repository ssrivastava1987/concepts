package com.apple.batch.dao.entity;

//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Id;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
public class EmployeeDetails {
	
	@Id
    @Column (name = "ID", nullable = false)
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private long id;
	@NotNull
    @Column (name = "personal_id", nullable = false)
	private String personalId;
	@NotNull
	@Column (name = "first_name", nullable = false)
	private String firstName;
	@NotNull
	@Column (name = "last_name", nullable = false)
	private String lastName;
	
	//From Merlin
//	private Address address;
	@NotNull
	@Column (name = "addr_line_1", nullable = false)
	private String addressLine1;
	@NotNull
	@Column (name = "addr_line_2", nullable = false)
	private String addressLine2;
	@NotNull
	@Column (name = "city", nullable = false)
	private String city;
	@NotNull
	@Column (name = "state", nullable = false)
	private String state;
	@NotNull
	@Column (name = "zip", nullable = false)
	private String zip;
	
	@NotNull
	@Column (name = "date_of_birth", nullable = false)
	private String dateOfBirth;
	@NotNull
	@Column (name = "job_title", nullable = false)
	private String jobTitle;
	
//	private Department department;
	@NotNull
	@Column (name = "dept_number", nullable = false)
	private String deptNumber;
	@NotNull
	@Column (name = "dept_name", nullable = false)
	private String deptName;
	@NotNull
	@Column (name = "dept_site_number", nullable = false)
	private String deptSiteNumber;
	
	@NotNull
	@Column (name = "company_name", nullable = false)
	private String companyName;
	@NotNull
	@Column (name = "building_name", nullable = false)
	private String buildingName;
	@NotNull
	@Column (name = "location_name", nullable = false)
	private String locationName;
	
	@NotNull
	@Column (name = "phone", nullable = false)
	private String phone;
	@NotNull
	@Column (name = "ext", nullable = false)
	private String ext;
	@NotNull
	@Column (name = "mobile_phone", nullable = false)
	private String mobilePhone;
	@NotNull
	@Column (name = "email_address", nullable = false)
	private String emailAddress;
	
	@NotNull
	@Column (name = "manager_name", nullable = false)
	private String managerName;
	@NotNull
	@Column (name = "manager_email_address", nullable = false)
	private String managerEmailAddress;
	@NotNull
	@Column (name = "manager_phone_number", nullable = false)
	private String managerPhoneNumber;
	
	//From Merlin
	@NotNull
	@Column (name = "area_manager_name", nullable = false)
	private String areaManagername;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPersonalId() {
		return personalId;
	}

	public void setPersonalId(String personalId) {
		this.personalId = personalId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

//	public Address getAddress() {
//		return address;
//	}
//
//	public void setAddress(Address address) {
//		this.address = address;
//	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

//	public Department getDepartment() {
//		return department;
//	}
//
//	public void setDepartment(Department department) {
//		this.department = department;
//	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getExt() {
		return ext;
	}

	public void setExt(String ext) {
		this.ext = ext;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getManagerEmailAddress() {
		return managerEmailAddress;
	}

	public void setManagerEmailAddress(String managerEmailAddress) {
		this.managerEmailAddress = managerEmailAddress;
	}

	public String getManagerPhoneNumber() {
		return managerPhoneNumber;
	}

	public void setManagerPhoneNumber(String managerPhoneNumber) {
		this.managerPhoneNumber = managerPhoneNumber;
	}

	public String getAreaManagername() {
		return areaManagername;
	}

	public void setAreaManagername(String areaManagername) {
		this.areaManagername = areaManagername;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getDeptNumber() {
		return deptNumber;
	}

	public void setDeptNumber(String deptNumber) {
		this.deptNumber = deptNumber;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptSiteNumber() {
		return deptSiteNumber;
	}

	public void setDeptSiteNumber(String deptSiteNumber) {
		this.deptSiteNumber = deptSiteNumber;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

}
