package com.apple.batch.dao.entity;

public class Department {
	
	private String deptNumber;
	private String deptName;
	private String deptSiteNumber;
	
	public String getDeptNumber() {
		return deptNumber;
	}
	public void setDeptNumber(String deptNumber) {
		this.deptNumber = deptNumber;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptSiteNumber() {
		return deptSiteNumber;
	}
	public void setDeptSiteNumber(String deptSiteNumber) {
		this.deptSiteNumber = deptSiteNumber;
	}
	
	
	

}
