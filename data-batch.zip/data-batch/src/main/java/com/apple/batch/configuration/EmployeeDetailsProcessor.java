package com.apple.batch.configuration;

import org.springframework.batch.item.ItemProcessor;

import com.apple.batch.dao.entity.EmployeeDetails;

public class EmployeeDetailsProcessor implements ItemProcessor<EmployeeDetails, EmployeeDetails>{

    @Override
    public EmployeeDetails process(final EmployeeDetails employeeDetails) {
    	
//    	final long ID = employeeDetails.getId();
    	final String personal_id = employeeDetails.getPersonalId();
    	final String first_name = employeeDetails.getFirstName();
    	final String last_name = employeeDetails.getLastName();
    	final String addr_line_1 = employeeDetails.getAddressLine1();
    	final String addr_line_2 = employeeDetails.getAddressLine2();
    	final String city = employeeDetails.getCity();
    	final String state = employeeDetails.getState();
    	final String zip = employeeDetails.getZip();
    	final String date_of_birth = employeeDetails.getDateOfBirth();
    	final String job_title = employeeDetails.getJobTitle();
    	final String dept_number = employeeDetails.getDeptNumber();
    	final String dept_name = employeeDetails.getDeptName();
    	final String dept_site_number = employeeDetails.getDeptSiteNumber();
    	final String company_name = employeeDetails.getCompanyName();
    	final String building_name = employeeDetails.getBuildingName();
    	final String location_name = employeeDetails.getLocationName();
    	final String phone = employeeDetails.getPhone();
    	final String ext = employeeDetails.getExt();
    	final String mobile_phone = employeeDetails.getMobilePhone();
    	final String email_address = employeeDetails.getEmailAddress();
    	final String manager_name = employeeDetails.getManagerName();
    	final String manager_email_address = employeeDetails.getManagerEmailAddress();
    	final String manager_phone_number = employeeDetails.getManagerPhoneNumber();
    	final String area_manager_name = employeeDetails.getAreaManagername();

        final EmployeeDetails processedEmployeeDetails = new EmployeeDetails();
//        processedEmployeeDetails.setId(ID);
        processedEmployeeDetails.setPersonalId(personal_id);
        processedEmployeeDetails.setFirstName(first_name);
        processedEmployeeDetails.setLastName(last_name);
        processedEmployeeDetails.setAddressLine1(addr_line_1);
        processedEmployeeDetails.setAddressLine2(addr_line_2);
        processedEmployeeDetails.setCity(city);
        processedEmployeeDetails.setState(state);
        processedEmployeeDetails.setZip(zip);
        processedEmployeeDetails.setDateOfBirth(date_of_birth);
        processedEmployeeDetails.setJobTitle(job_title);
        processedEmployeeDetails.setDeptNumber(dept_number);
        processedEmployeeDetails.setDeptName(dept_name);
        processedEmployeeDetails.setDeptSiteNumber(dept_site_number);
        processedEmployeeDetails.setCompanyName(company_name);
        processedEmployeeDetails.setBuildingName(building_name);
        processedEmployeeDetails.setLocationName(location_name);
        processedEmployeeDetails.setPhone(phone);
        processedEmployeeDetails.setExt(ext);
        processedEmployeeDetails.setMobilePhone(mobile_phone);
        processedEmployeeDetails.setEmailAddress(email_address);
        processedEmployeeDetails.setManagerName(manager_name);
        processedEmployeeDetails.setManagerEmailAddress(manager_email_address);
        processedEmployeeDetails.setManagerPhoneNumber(manager_phone_number);
        processedEmployeeDetails.setAreaManagername(area_manager_name);
        return processedEmployeeDetails;
    }
}
