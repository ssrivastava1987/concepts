package com.apple.batch.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.apple.batch.dao.entity.EmployeeDetails;


public interface IEmployeeDetailsRepository extends JpaRepository<EmployeeDetails, Long> {

}
