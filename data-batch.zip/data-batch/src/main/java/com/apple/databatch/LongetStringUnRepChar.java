package com.apple.databatch;

import java.util.ArrayList;
import java.util.List;

public class LongetStringUnRepChar {

	public static void main(String[] args) {
		List<String> inputs = new ArrayList<String>();
		inputs.add("abcabcbb"); //3
		inputs.add("bbbbb");//1
		inputs.add("pwwkew");//3
		inputs.add("dvdf");//3
		inputs.add("Shubham");//4
		for(String a : inputs) {
			System.out.println(lengthOfLongestSubstring(a));
		}
	}
	
	public static int lengthOfLongestSubstring(String s) {
        StringBuilder sbr = new StringBuilder();
        List<Character> charList = new ArrayList<Character>();
        int k = 0;
        if(s.length()==1) {
        	k = 1;
        }
        for(int i=0;i<s.length();i++){
        	if(!charList.contains(s.charAt(i))) {
        		sbr.append(s.charAt(i));
        		charList.add(s.charAt(i));
        		if(k<sbr.length()) {
        			k = sbr.length();
        		}
        	} else {
        		if(k<sbr.length()) {
        			k = sbr.length();
        		}
        		
        		for(int j=i-1;j>=0;j--) {
        			if(s.charAt(j) == s.charAt(i)) {
        			i = j;
        			break;
        			}
        		}
        		
        		sbr = new StringBuilder();
        		charList = new ArrayList<Character>();
        		
        	}
        	
        }
        charList.clear();
        return k;
    }
	

}