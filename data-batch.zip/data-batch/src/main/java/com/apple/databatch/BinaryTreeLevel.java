package com.apple.databatch;

import java.util.LinkedList;
import java.util.Queue;

/* Constructed binary tree is 
*      1    = 0
*    /   \ 
*   2     3   = 1
*  /  \  / 
* 4    5 8    = 2
* 
*/

public class BinaryTreeLevel {
	
	Node root;   

	public static void main(String[] args) {
		
		BinaryTreeLevel tree = new BinaryTreeLevel(); 
         
	      
	        tree.root = new Node(1); 
	        tree.root.left = new Node(2); 
	        tree.root.right = new Node(3); 
	        tree.root.left.left = new Node(4); 
	        tree.root.left.right = new Node(5); 
	        tree.root.right.left = new Node(8); 
	   
	        tree.printKDistant(tree.root, 1);
	        tree.printKDistant(tree.root, 2); 
	        tree.printKDistant(tree.root, 3); 
	        tree.printKDistant(tree.root, 4); 
	        tree.printKDistant(tree.root, 5); 
	        tree.printKDistant(tree.root, 6); 
	}
	
	public void printKDistant(Node root2, int i) {
	    
		Queue<Node> q = new LinkedList<Node>();
		q.add(root2);
		
		int level = 0;
		q.add(null);
		while(!q.isEmpty()) {
			Node temp = q.poll();
			if(temp == null) {
				if(q.peek()!=null) {
					q.add(null);
				}
				level = level+1;
				
			} else {
				if(temp.data==i) {
					System.out.println(level);
					break;
				} 
				if(temp.left!=null){
					q.add(temp.left);
				}
				if(temp.right!=null) {
					q.add(temp.right);
				}
			}
			
		}
		
	    
	} 

}

class Node {
	
	int data;
	Node left;
	Node right;
	
	Node(int data){
		this.data = data;
		this.left = this.right = null;
	}
	
}
