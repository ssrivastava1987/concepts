package com.apple.databatch;

import java.util.HashMap;
import java.util.Map;

public class OracleQuestion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String input  = "you got beautiful eyes";
		char[] inputArr = new char[50];
		for(int k = 0 ; k<input.length();k++){
			
			inputArr[k] = input.charAt(k);
			
		}
		
		Map<Character,Integer> map = new HashMap<Character,Integer>();
		char[] outputArr = new char[inputArr.length];
		
		for (int i=0;i<inputArr.length;i++) {
			
			
			if(!map.containsKey(inputArr[i])) {
				map.put(inputArr[i], 1);
				outputArr[i] = inputArr[i];
				
			} else {
				map.remove(inputArr[i]);
			}
			
		}
		System.out.println(outputArr);

	}

}
