package com.apple.databatch;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

class MyCode {
  public static void main (String[] args) {
    System.out.println("Hello Java");
    int[] arr1 = {1, 3, 4, 5};
    int[] arr2 = {2, 4, 6, 8};
    Set<Integer> set = new LinkedHashSet<Integer>();
    if(arr1.length>arr2.length){
      for(int i=0;i<arr1.length;i++){
          if(arr1[i] < arr2[i]){
            set.add(arr1[i]);
            set.add(arr2[i]);
          } else if (arr1[i] > arr2[i]) {
            set.add(arr2[i]);
            set.add(arr1[i]);
          } else {
            set.add(arr1[i]);
          }
      }
    } else if(arr1.length<arr2.length){
      
      for(int i=0;i<arr2.length;i++){
          if(arr2[i] < arr1[i]){
            set.add(arr2[i]);
            set.add(arr1[i]);
          } else if (arr2[i] > arr1[i]) {
            set.add(arr1[i]);
            set.add(arr2[i]);
          } else {
            set.add(arr2[i]);
          }
      }
      
    } else {
      
      for(int i=0;i<arr1.length;i++){
            if(arr1[i] < arr2[i]){
              set.add(arr1[i]);
              set.add(arr2[i]);
            } else if (arr1[i] > arr2[i]) {
              set.add(arr2[i]);
              set.add(arr1[i]);
            }
        }
      
    }
    List<Integer> x = set.stream().collect(Collectors.toList());
    set.clear();
    Collections.sort(x);
    x.forEach(System.out::println);
    
  }
}
