package com.apple.dataintegration.configration;

import org.springframework.context.annotation.Configuration;

@Configuration
public class DataIntegrationConfigration {
	
	

}
