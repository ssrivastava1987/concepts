package com.apple.dataintegration.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.apple.dataintegration.entity.EmployeeDetails;
import com.apple.dataintegration.service.EmployeeDetailsService;
import com.apple.dataintegration.service.ProducerService;

@RestController
@RequestMapping("/employee")
public class EmployeeDetailsController {
	
	@Autowired
	private EmployeeDetailsService employeeDetailsService;
	private final ProducerService producer;
	
	@Autowired
	EmployeeDetailsController(ProducerService producer) {
        this.producer = producer;
    }
	
	@GetMapping(path = "/details",produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<EmployeeDetails> getAllRequiredField(){
		return employeeDetailsService.getAllEmployees();
	}
	
	@GetMapping(path = "/details/all",produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody int getCount(){
		return employeeDetailsService.getCount();
	}
	
	@PostMapping(value = "/publish",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public void sendMessageToKafkaTopic(@RequestBody EmployeeDetails message) {
        this.producer.sendMessage(message);
    }

}
