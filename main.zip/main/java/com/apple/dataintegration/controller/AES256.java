package com.apple.dataintegration.controller;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.KeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.Random;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class AES256 {

    private static String secretKey = UUID.randomUUID().toString();
    private static String salt = UUID.randomUUID().toString();

    public static String encrypt(String strToEncrypt, String secret)
    {
        try
        {
            byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            IvParameterSpec ivspec = new IvParameterSpec(iv);

            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
            SecretKey tmp = factory.generateSecret(spec);
            SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
            return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
        }
        catch (Exception e)
        {
            System.out.println("Error while encrypting: " + e.toString());
        }
        return null;
    }

    public static String decrypt(String strToDecrypt, String secret) {
        try
        {
            byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            IvParameterSpec ivspec = new IvParameterSpec(iv);

            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
            SecretKey tmp = factory.generateSecret(spec);
            SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        }
        catch (Exception e) {
            System.out.println("Error while decrypting: " + e.toString());
        }
        return null;
    }

    public static void main(String[] args)
    {
        String originalString = "{\n" +
                "  \"ai_sap_numbers\": \"W-SAP_NUMBER\",\n" +
                "  \"ai_pos_recipts\": \"R-POS_RECEIPT\",\n" +
                "  \"ai_serial_numbers\": \"12345678901\",\n" +
                "  \"ai_imei_numbers\": \"123456789012345\",\n" +
                "  \"ai_meid_numbers\": \"12345678901234\",\n" +
                "  \"ai_guid_numbers\": \"1234567890A234567890B234567890C234567890\",\n" +
                "  \"case_number\": \"case number\",\n" +
                "  \"due_date\": \"May 16, 2020\",\n" +
                "  \"email_addresses\": [\"email1@example.com\", \"email2@example.com\"],\n" +
                "  \"expedited_processing\": \"I don't need to.  Just DO IT!!\",\n" +
                "  \"incident_date\": \"February 16, 2020 to March 16, 2020\",\n" +
                "  \"incident_description\": \"this thing happened\",\n" +
                "  \"information_requested\": \"info requested\",\n" +
                "  \"is_primary_production_contact\": \"yes\",\n" +
                "  \"itunes_web_orders\": \"M-WEB_ORDER\",\n" +
                "  \"legal_basis\": \"legal basis\",\n" +
                "  \"location\": \"here\",\n" +
                "  \"matter_type\": \"court_order\",\n" +
                "  \"other_account_identifiers\": \"other account identifiers\",\n" +
                "  \"other_contact_first_name\": \"other1first\",\n" +
                "  \"other_contact_last_name\": \"other1last\",\n" +
                "  \"other_contact_email\": \"other1@example.com\",\n" +
                "  \"other_contact_agency\": \"other1 agency\",\n" +
                "  \"other_identifiers\": \"other junk-drawer-type of things\",\n" +
                "  \"primary_contact_first_name\": \"primaryfirst\",\n" +
                "  \"primary_contact_last_name\": \"primarylast\",\n" +
                "  \"primary_contact_email\": \"primaryemail@example.com\",\n" +
                "  \"primary_contact_agency\": \"primary agency\",\n" +
                "  \"related_records\": \"related records\",\n" +
                "  \"video_ai_pos_recipts\": \"video receipts\",\n" +
                "  \"video_incident_time\": \"05:54:53 PM\",\n" +
                "  \"video_request_type\": \"video_only\",\n" +
                "  \"video_retail_store_location\": \"retail store location\",\n" +
                "  \"video_other_info\": \"video other info\"\n" +
                "}";

        String encryptedString = AES256.encrypt(originalString, secretKey) ;
        String decryptedString = AES256.decrypt(encryptedString, secretKey) ;

        System.out.println(originalString);
        System.out.println(encryptedString);
        System.out.println(decryptedString);
    }

}
