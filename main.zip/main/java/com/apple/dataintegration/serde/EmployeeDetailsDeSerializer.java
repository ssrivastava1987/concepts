package com.apple.dataintegration.serde;

import org.springframework.kafka.support.serializer.JsonDeserializer;

import com.apple.dataintegration.entity.EmployeeDetails;

public class EmployeeDetailsDeSerializer extends JsonDeserializer<EmployeeDetails>{

}
