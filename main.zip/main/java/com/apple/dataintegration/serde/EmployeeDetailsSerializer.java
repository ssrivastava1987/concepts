package com.apple.dataintegration.serde;

import org.springframework.kafka.support.serializer.JsonSerializer;

import com.apple.dataintegration.entity.EmployeeDetails;

public class EmployeeDetailsSerializer extends JsonSerializer<EmployeeDetails>{

}
