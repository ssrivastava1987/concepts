package com.apple.dataintegration.myimpl;

public class DSImpl {

    static class Node {
        Node next;
        char data;

        public Node(char d){
            data = d;
        }
    }

    public static void main(String[] args) {
            Node a = new Node('A');
            Node b = new Node('S');

            a.next = b;

            System.out.println(a.data + " " + a.next.data);

    }
}
