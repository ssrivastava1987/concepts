package com.apple.dataintegration.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DSBLDGPUB_INCOMING_DATA", schema = "REDSD_OWNER")
public class OfficeAddress implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
    @Column(name = "BLDG_ID")
	private long buildingID;
	@Column(name = "BLDG_NM")
	private String buildingName;
	@Column(name = "LOC_NM")
	private String locationName;
	@Column(name = "ADDR_LINE1")
	private String addressLine1;
	@Column(name = "ADDR_LINE2")
	private String addressLine2;
	@Column(name = "ADDR_CITY_NM") // OR ADDR_CITY_NM_LONG
	private String city;
	@Column(name = "ADDR_STATE_PROVINCE_NM")
	private String state;
	@Column(name = "COUNTRY_NM")
	private String country;
	@Column(name = "ADDR_POSTAL_CD")
	private String zip;
	
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public long getBuildingID() {
		return buildingID;
	}
	public void setBuildingID(long buildingID) {
		this.buildingID = buildingID;
	}
	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
}
