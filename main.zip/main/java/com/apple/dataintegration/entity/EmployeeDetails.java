/*
 * Copyright 2020 Apple, Inc
 * Apple Internal Use Only
 */


package com.apple.dataintegration.entity;



import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DS_VIMS_DATA_VW_P", schema = "REDSD_OWNER")
public class EmployeeDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
    @Column(name = "PRS_ID")
    private long personalId;
    @Column(name = "PRS_FIRST_NM")
    private String firstName;
    @Column(name = "PRS_LAST_NM")
    private String lastName;
    @Column(name = "PRS_DEPT_NUM")
    private String deptNumber;
    @Column(name = "PRS_DEPT_NM")
    private String deptName;
    @Column(name = "PRS_DEPT_SITE_NUM")
    private String deptSiteNumber;
    @Column(name = "COMPANY_NM")
    private String companyName;
    @Column(name = "BLDG_NM")
    private String buildingName;
    @Column(name = "LOC_NM")
    private String locationName;
    @Column(name = "PRS_PHONE_NO")
    private String phone;
    @Column(name = "PRS_PHONE_NO_EXTN")
    private String ext;
    @Column(name = "PRS_MOBILE_NO")
    private String mobilePhone;
    @Column(name = "PRS_EMAIL_INTERNET_ADDR")
    private String emailAddress;
    @Column(name = "NEW_MANAGER_ID")
    private long managerId;
    
//    @OneToOne(cascade = CascadeType.ALL)
//    @JoinColumn(name = "BLDG_NM", referencedColumnName = "BLDG_ID")
//    private OfficeAddress address;
    
//	public OfficeAddress getAddress() {
//		return address;
//	}
//
//
//	public void setAddress(OfficeAddress address) {
//		this.address = address;
//	}


	public String getDeptNumber() {
		return deptNumber;
	}


	public void setDeptNumber(String deptNumber) {
		this.deptNumber = deptNumber;
	}


	public long getPersonalId() {
		return personalId;
	}


	public void setPersonalId(long personalId) {
		this.personalId = personalId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getDeptName() {
		return deptName;
	}


	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}


	public String getDeptSiteNumber() {
		return deptSiteNumber;
	}


	public void setDeptSiteNumber(String deptSiteNumber) {
		this.deptSiteNumber = deptSiteNumber;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public String getBuildingName() {
		return buildingName;
	}


	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}


	public String getLocationName() {
		return locationName;
	}


	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getExt() {
		return ext;
	}


	public void setExt(String ext) {
		this.ext = ext;
	}


	public String getMobilePhone() {
		return mobilePhone;
	}


	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}


	public String getEmailAddress() {
		return emailAddress;
	}


	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}


	public long getManagerId() {
		return managerId;
	}


	public void setManagerId(long managerId) {
		this.managerId = managerId;
	}

}
