package com.apple.dataintegration.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.apple.dataintegration.entity.EmployeeDetails;
import com.apple.dataintegration.repository.EmployeeDetailsRepository;
import com.apple.dataintegration.service.EmployeeDetailsService;

@Service
public class EmployeeDetailsServiceImpl implements EmployeeDetailsService{
	
	@Autowired
	private EmployeeDetailsRepository employeeDetailsRepository;
	@Override
	public List<EmployeeDetails> getAllEmployees() {
		return (List<EmployeeDetails>) employeeDetailsRepository.findAll();
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return (int) employeeDetailsRepository.count();
	}

}
