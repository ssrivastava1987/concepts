package com.apple.dataintegration.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.apple.dataintegration.entity.EmployeeDetails;
import com.apple.dataintegration.service.ConsumerService;

@Service
public class ConsumerServiceimpl implements ConsumerService {

	private final Logger logger = LoggerFactory.getLogger(ConsumerServiceimpl.class);
	@Override
	@KafkaListener(topics = "test", groupId = "group_id")
	public void consume(EmployeeDetails message) {
		// TODO Auto-generated method stub
		logger.info(String.format("#### -> Consumed message -> %s", message));
	}

}
