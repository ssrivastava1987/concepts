package com.apple.dataintegration.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.apple.dataintegration.entity.EmployeeDetails;
import com.apple.dataintegration.service.ProducerService;

@Service
public class ProducerServiceImpl implements ProducerService{
	
	private static final String TOPIC = "test";
	private static final Logger logger = LoggerFactory.getLogger(ProducerServiceImpl.class);

    @Autowired
    private KafkaTemplate<String, EmployeeDetails> kafkaTemplate;

	@Override
	public void sendMessage(EmployeeDetails message) {
		// TODO Auto-generated method stub
		logger.info(String.format("#### -> Producing message -> %s", message));
        this.kafkaTemplate.send(TOPIC, message);
		
	}

}
