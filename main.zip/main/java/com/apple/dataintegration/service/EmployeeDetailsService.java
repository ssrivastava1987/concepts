package com.apple.dataintegration.service;

import java.util.List;

import com.apple.dataintegration.entity.EmployeeDetails;

public interface EmployeeDetailsService {
	
	public List<EmployeeDetails> getAllEmployees();
	public int getCount();

}
