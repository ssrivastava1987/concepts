package com.apple.dataintegration.service;

import com.apple.dataintegration.entity.EmployeeDetails;

public interface ConsumerService {
	
	public void consume(EmployeeDetails message);

}
