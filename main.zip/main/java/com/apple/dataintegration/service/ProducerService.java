package com.apple.dataintegration.service;

import com.apple.dataintegration.entity.EmployeeDetails;

public interface ProducerService {
	
	public void sendMessage(EmployeeDetails message);

}
