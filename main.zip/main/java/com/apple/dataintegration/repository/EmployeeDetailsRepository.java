package com.apple.dataintegration.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.apple.dataintegration.entity.EmployeeDetails;

public interface EmployeeDetailsRepository extends CrudRepository<EmployeeDetails, Long>{
	
//	@Query(countQuery = "select count(*) from REDSD_OWNER.ds_vims_data_vw_p",nativeQuery = true)
	public long count();

}
