package com.apple.dataintegration.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.apple.dataintegration.entity.EmployeeDetails;

public interface EmployeeDetailsRepository extends CrudRepository<EmployeeDetails, Long>{
	
//	@Query(countQuery = "select count(*) from REDSD_OWNER.ds_vims_data_vw_p",nativeQuery = true)
	public long count();
	@Query(countQuery = "select   from REDSD_OWNER.ds_vims_data_vw_p vw,redsd_owner.dsbldgpub_incoming_data in",nativeQuery = true)
	public List<EmployeeDetails> getAll();

}
