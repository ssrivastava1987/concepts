package com.konek.fslexecute;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FslExecuteApplicationTests {

	@Test
	void contextLoads() {
	}

}
