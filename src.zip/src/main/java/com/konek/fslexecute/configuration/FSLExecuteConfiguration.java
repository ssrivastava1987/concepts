package com.konek.fslexecute.configuration;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Configuration;

@Configuration
public class FSLExecuteConfiguration {
	
private static Map<String,String> dataType = new HashMap<String, String>();
	
	static {
		dataType.put("var", "String");
		dataType.put("int", "Integer");
		dataType.put("float", "Float");
		dataType.put("double", "Double");
		dataType.put("long", "Long");
		
	}
	
	

}
