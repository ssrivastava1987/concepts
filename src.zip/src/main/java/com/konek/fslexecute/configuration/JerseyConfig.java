package com.konek.fslexecute.configuration;

import javax.annotation.PostConstruct;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.Configuration;

import com.konek.fslexecute.controller.FSLExecuteController;

@Configuration
public class JerseyConfig extends ResourceConfig {
	
	public JerseyConfig() 
    {
        
    }
	
	@PostConstruct
	public void setUp() {
		register(FSLExecuteController.class);
	}

}
