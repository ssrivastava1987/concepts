package com.konek.fslexecute.service;

import java.util.Map;
import java.util.Set;

public interface FSLExecuteService {
	
	public Map<String,String> update(String id, String value,Map<String,String> mainMap);
	
	public Map<String,String> create(String id, String value,Map<String,String> mainMap);
	
	public Set<String> read(String id,Map<String,String> mainMap);
	
	public Map<String,String> delete(String id,Map<String,String> mainMap);

}
