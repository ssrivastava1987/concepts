package com.konek.fslexecute.service.impl;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.konek.fslexecute.service.FSLExecuteService;

@Service
public class FSLExecuteServiceImpl implements FSLExecuteService{
	
	private Set<String> outSet = new LinkedHashSet<String>();
	
	public Map<String,String> update(String id, String value,Map<String,String> mainMap) {
		mainMap.put(id, value);
		return mainMap;
	}
	
	public Map<String,String> create(String id, String value,Map<String,String> mainMap) {
		mainMap.put(id, value);
		return mainMap;
	}
	
	public Set<String> read(String id,Map<String,String> mainMap) {
		String idPrint = id.replace('#', ' ').trim();
	    System.out.println(valueIsNull(mainMap.get(idPrint)));
	    outSet.add(valueIsNull(mainMap.get(idPrint)));
		return outSet;
	}
	
	public Map<String,String> delete(String id,Map<String,String> mainMap) {
		mainMap.remove(id);
		return mainMap;
	}
	
	private String valueIsNull(String value) {
	    return value == null ? "undefined" : value.toString();
	}

}
