package com.konek.fslexecute.controller;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.codehaus.jettison.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.konek.fslexecute.util.FSLUtil;

@Path("/fslexecute")
@Controller
public class FSLExecuteController {
	
	@Autowired
	private FSLExecuteFunctions fslExecuteFunctions;
	
	Map<String, String> mapMain = new LinkedHashMap<String, String>();
	
	@POST
	@Path("/getInFsl")
	@Consumes("application/json")
	@Produces("application/json")
	public String getFSLScript(@RequestBody String body) throws JSONException, JsonProcessingException {
		mapMain = FSLUtil.jsonToMap(body);
		for(Map.Entry<String, String> e : mapMain.entrySet()) {
			if(e.getValue().contains("[{")) {
				jsonToMapList(e.getKey(),e.getValue());
			}
		}
		Set<String> outSet = fslExecuteFunctions.execute("init",mapMain);
		StringBuffer out = new StringBuffer();
		for(String one : outSet) {
			out.append(one);
			out.append(System.lineSeparator());
		}
		return out.toString();
	}
	
	@GET
	public String getFSL() {
		return "hello fsl";
	}
	
	public void jsonToMapList( String key,String value) throws JSONException {

		if(value.contains("[")) {
			value = value.replace('[', ' ');
			value = value.replace(']', ' ');
		}
		
		mapMain.put(key, value);
    }


}
