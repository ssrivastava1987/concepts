package com.konek.fslexecute.controller;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import org.codehaus.jettison.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.konek.fslexecute.service.FSLExecuteService;
import com.konek.fslexecute.util.FSLUtil;

@Component
public class FSLExecuteFunctions {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FSLExecuteFunctions.class);
	
	@Autowired
	private FSLExecuteService fslExecuteService;
	
	Map<String,String> mapValue = new LinkedHashMap<String,String>();
	
	Set<String> outSet = new LinkedHashSet<String>();
	Set<String> outSetFinal = new LinkedHashSet<String>();
	
	public Set<String> execute(String startKey,Map<String,String> mainMap) throws JSONException {
		
		String init = mainMap.get(startKey);
		String[] initMethodArray = init.split("},");
		String initVal = null;
		for(String in : initMethodArray) {
			in = in+"}";
			Map<String,String> mapValueTemp = mapValue;
			mapValue = FSLUtil.jsonToMap(in);
			
			if(mapValue.get("cmd").equalsIgnoreCase("add") || mapValue.get("cmd").equalsIgnoreCase("substract")
					|| mapValue.get("cmd").equalsIgnoreCase("divide") || mapValue.get("cmd").equalsIgnoreCase("multiply")) {
				for(Map.Entry<String, String> e : mapValue.entrySet()) {
					if(e.getKey().equalsIgnoreCase("id")) {
						mapValue.put(e.getKey(), mapValueTemp.get(e.getKey()));
					} else if (e.getKey().contains("operand")) {
						mapValue.put(e.getKey(), mapValueTemp.get(e.getValue().replace('$', ' ').trim()));
					}
				}
			}
			
			if(mapValue.get("cmd").contains("#")) {
				initVal = mapValue.get("cmd").replace('#', ' ').trim();
				execute(initVal,mainMap);
			} else {
				outSetFinal = functionsCall(mainMap);
			}
		}
		return outSetFinal;
	}
	
	private Map<String, String> createOrUpdate(String id, String calcValue, Map<String, String> mainMap) {
		return mainMap.containsKey(id) ? fslExecuteService.update(id,calcValue,mainMap) : fslExecuteService.create(id,calcValue,mainMap);
	}
	
	private Set<String> functionsCall(Map<String,String> mainMap) {
		
		if (mapValue.get("cmd").equalsIgnoreCase("update")) {
			mainMap = fslExecuteService.update(mapValue.get("id"),mapValue.get("value"),mainMap);
		} else if (mapValue.get("cmd").equalsIgnoreCase("print")) {
			outSet = fslExecuteService.read(mapValue.get("value"),mainMap);
		} else if (mapValue.get("cmd").equalsIgnoreCase("delete")) {
			mainMap = fslExecuteService.delete(mapValue.get("id"),mainMap);
		} else if (mapValue.get("cmd").equalsIgnoreCase("create")) {
			mainMap = fslExecuteService.create(mapValue.get("id"),mapValue.get("value"),mainMap);
		} else if(mapValue.get("cmd").equalsIgnoreCase("add") || mapValue.get("cmd").equalsIgnoreCase("substract")
				|| mapValue.get("cmd").equalsIgnoreCase("divide") || mapValue.get("cmd").equalsIgnoreCase("multiply")){
			mainMap = mathematicalCalculations(mapValue,mainMap);
		}
		return outSet;
	}
	
	private Map<String, String> mathematicalCalculations(Map<String, String> mapValue, Map<String, String> mainMap) {
		
		int calculatedValue = 0;
		
		Map<String, String> returnMap =  new LinkedHashMap<String, String>();
		try {
		if (mapValue.get("cmd").equalsIgnoreCase("add")) {
			for(Map.Entry<String, String> ent : mapValue.entrySet()) {
				if(ent.getKey().contains("operand")) {
					calculatedValue = calculatedValue + Integer.parseInt(mainMap.get(ent.getValue().replace('#', ' ').trim()));
				}
			}
			returnMap = createOrUpdate(mapValue.get("id"),String.valueOf(calculatedValue),mainMap);
		}
		
		if (mapValue.get("cmd").equalsIgnoreCase("substract")) {
			int k = 0;
			for(Map.Entry<String, String> ent : mapValue.entrySet()) {
				if(ent.getKey().contains("operand")) {
					if(k==0) {
						calculatedValue = Integer.parseInt(mainMap.get(ent.getValue().replace('#', ' ').trim()));
						k = 1;
					} else {
					calculatedValue = calculatedValue - Integer.parseInt(mainMap.get(ent.getValue().replace('#', ' ').trim()));
					}
				}
			}
			returnMap = createOrUpdate(mapValue.get("id"),String.valueOf(calculatedValue),mainMap);
		}
		
		if (mapValue.get("cmd").equalsIgnoreCase("divide")) {
			int k = 0;
			for(Map.Entry<String, String> ent : mapValue.entrySet()) {
				if(ent.getKey().contains("operand")) {
					if(k==0) {
						calculatedValue = Integer.parseInt(mainMap.get(ent.getValue().replace('#', ' ').trim()));
						k = 1;
					} else {
					calculatedValue = calculatedValue / Integer.parseInt(mainMap.get(ent.getValue().replace('#', ' ').trim()));
					}
				}
			}
			returnMap = createOrUpdate(mapValue.get("id"),String.valueOf(calculatedValue),mainMap);
		}
		
		if (mapValue.get("cmd").equalsIgnoreCase("multiply")) {
			int k = 0;
			for(Map.Entry<String, String> ent : mapValue.entrySet()) {
				if(ent.getKey().contains("operand")) {
					if(k==0) {
						calculatedValue = Integer.parseInt(mainMap.get(ent.getValue().replace('#', ' ').trim()));
						k = 1;
					} else {
					calculatedValue = calculatedValue * Integer.parseInt(mainMap.get(ent.getValue().replace('#', ' ').trim()));
					}
				}
			}
			returnMap = createOrUpdate(mapValue.get("id"),String.valueOf(calculatedValue),mainMap);
		}
		} catch(NumberFormatException e) {
			LOGGER.error(e.getMessage());
		} catch(Exception e) {
			LOGGER.error(e.getMessage());
		}
		return returnMap;
	}
}
